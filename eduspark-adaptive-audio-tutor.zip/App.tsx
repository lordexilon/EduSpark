
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { InteractionMode } from './types';
import type { ChatMessage, AudioCapabilities } from './types';
import { useAudioCapabilities } from './hooks/useAudioCapabilities';
import { getTutorResponse, synthesizeSpeech, processDocument } from './services/geminiService';
import { AttachmentIcon, LoadingSpinner, MicrophoneIcon, PauseIcon, PlayIcon, SendIcon, TrashIcon, ExportIcon } from './components/icons';

// Add pdf.js library to the global scope for TypeScript
declare const pdfjsLib: any;

// Audio decoding utilities
const decodeBase64 = (base64: string) => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

const decodeAudioData = async (
  data: Uint8Array,
  ctx: AudioContext
): Promise<AudioBuffer> => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length;
  const buffer = ctx.createBuffer(1, frameCount, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < frameCount; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
};


// Main App Component
export default function App() {
  const capabilities = useAudioCapabilities();
  const [interactionMode, setInteractionMode] = useState<InteractionMode>(InteractionMode.SILENT);
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const storedMessages = localStorage.getItem('eduspark-chat-history');
      if (storedMessages) {
        return JSON.parse(storedMessages);
      }
    } catch (error) {
      console.error("Failed to parse chat history from localStorage", error);
      localStorage.removeItem('eduspark-chat-history');
    }
    return [{ id: 'init', role: 'ai', text: '¡Bienvenido a EduSpark! ¿Cómo puedo ayudarte a aprender hoy?' }];
  });
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [isAudioPaused, setIsAudioPaused] = useState(false);
  const [documentPreview, setDocumentPreview] = useState<{content: string, id: string} | null>(null);

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const listeningIntentRef = useRef(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    // Configure the worker for pdf.js to prevent errors.
    if (typeof pdfjsLib !== 'undefined') {
      pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.worker.mjs`;
    }
  }, []);

  useEffect(() => {
    if (messages.length > 1 || (messages.length === 1 && messages[0].id !== 'init')) {
      localStorage.setItem('eduspark-chat-history', JSON.stringify(messages));
    }
  }, [messages]);

  useEffect(() => {
    if (capabilities) {
      if (capabilities.hasMicrophone && capabilities.hasSpeakers && capabilities.supportsSpeechRecognition) {
        setInteractionMode(InteractionMode.HYBRID);
      } else {
        setInteractionMode(InteractionMode.SILENT);
      }
    }
  }, [capabilities]);
  
  useEffect(() => {
    if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, documentPreview]);

  const stopAudio = useCallback(() => {
    if (audioSourceRef.current) {
      audioSourceRef.current.stop();
      audioSourceRef.current.disconnect();
      audioSourceRef.current = null;
    }
    setSpeakingMessageId(null);
    setIsAudioPaused(false);
  }, []);

  const playAudio = useCallback(async (text: string, messageId: string) => {
    if (speakingMessageId === messageId && isAudioPaused) {
        audioContextRef.current?.resume();
        setIsAudioPaused(false);
        return;
    }
    stopAudio();
    setSpeakingMessageId(messageId);
    setIsLoading(true);

    const audioContent = await synthesizeSpeech(text);
    setIsLoading(false);
    if (audioContent) {
      if (!audioContextRef.current) {
        // Fix: Use 'webkitAudioContext' as it is now typed on the Window object.
        audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      }
      const audioContext = audioContextRef.current;
      const audioData = decodeBase64(audioContent);
      const buffer = await decodeAudioData(audioData, audioContext);
      
      const source = audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContext.destination);
      source.start();
      source.onended = () => {
        if (speakingMessageId === messageId) {
          stopAudio();
        }
      };
      audioSourceRef.current = source;
    }
  }, [stopAudio, speakingMessageId, isAudioPaused]);


  useEffect(() => {
    if (!capabilities?.supportsSpeechRecognition) return;

    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognitionRef.current = new SpeechRecognitionAPI();
    const recognition = recognitionRef.current;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'es-ES';

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(transcript);
      // Automatically submit after successful recognition
      handleSubmit(new Event('submit') as any, transcript);
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
      listeningIntentRef.current = false;
    };

    recognition.onend = () => {
      // Only set listening to false if we didn't intentionally stop it
      if (listeningIntentRef.current) {
        listeningIntentRef.current = false;
      }
      setIsListening(false);
    };
  }, [capabilities?.supportsSpeechRecognition]);


  const toggleListening = () => {
    if (isListening) {
      listeningIntentRef.current = false;
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      listeningIntentRef.current = true;
      recognitionRef.current?.start();
      setIsListening(true);
      setInputValue(''); // Clear input on listen
    }
  };
  
  const handleModeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newMode = e.target.value as InteractionMode;
    setInteractionMode(newMode);
    if (newMode === InteractionMode.SILENT || newMode === InteractionMode.HYBRID) {
        stopAudio();
        if(isListening) toggleListening();
    }
  };
  
  const handleSubmit = useCallback(async (e: React.FormEvent, directInput?: string) => {
    e.preventDefault();
    const userInput = directInput || inputValue;
    if (!userInput.trim() || isLoading) return;

    stopAudio();
    setIsLoading(true);
    setInputValue('');

    const userMessage: ChatMessage = { id: Date.now().toString(), role: 'user', text: userInput };
    setMessages(prev => [...prev, userMessage]);

    const aiResponseText = await getTutorResponse(userInput);
    const aiMessage: ChatMessage = { id: (Date.now() + 1).toString(), role: 'ai', text: aiResponseText };
    setMessages(prev => [...prev, aiMessage]);
    
    setIsLoading(false);

    if (interactionMode === InteractionMode.AUDIO || interactionMode === InteractionMode.HYBRID) {
      await playAudio(aiResponseText, aiMessage.id);
    }
  }, [inputValue, isLoading, stopAudio, interactionMode, playAudio]);

  const handleAttachFile = () => {
    fileInputRef.current?.click();
  };
  
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Reset file input to allow re-selection of the same file
    event.target.value = '';

    const MAX_FILE_SIZE = 35 * 1024 * 1024; // 35MB
    if (file.size > MAX_FILE_SIZE) {
      const errorMsg = "El archivo es demasiado grande. El tamaño máximo es de 35 MB.";
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'ai', text: errorMsg }]);
      return;
    }
    
    setIsProcessingFile(true);
    let fileContent = '';

    try {
        if (file.type === 'application/pdf') {
            const fileReader = new FileReader();
            fileReader.onload = async (e) => {
                const typedarray = new Uint8Array(e.target?.result as ArrayBuffer);
                
                try {
                    const pdf = await pdfjsLib.getDocument(typedarray).promise;
                    let textContent = '';
                    for (let i = 1; i <= pdf.numPages; i++) {
                        const page = await pdf.getPage(i);
                        const text = await page.getTextContent();
                        textContent += text.items.map((s: any) => s.str).join(' ');
                    }
                    if (!textContent.trim()) {
                         throw new Error("PDF does not contain selectable text.");
                    }
                    fileContent = textContent;
                    const processedContent = await processDocument(fileContent);
                    setDocumentPreview({ content: processedContent, id: Date.now().toString() });
                    setIsProcessingFile(false);
                } catch (pdfError) {
                    console.error("Error processing PDF:", pdfError);
                    const errorMsg = "Lo siento, no pude leer el texto de este PDF. Puede que sea una imagen o esté dañado. Por favor, prueba con otro archivo.";
                    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'ai', text: errorMsg }]);
                    setIsProcessingFile(false);
                }
            };
            fileReader.readAsArrayBuffer(file);
            return; // Exit here and let the async reader handle the rest
        } else if (file.type === 'text/plain' || file.type === 'text/markdown') {
            fileContent = await file.text();
        } else {
             const errorMsg = "Tipo de archivo no compatible. Por favor, sube un archivo .txt, .md o .pdf.";
            setMessages(prev => [...prev, { id: Date.now().toString(), role: 'ai', text: errorMsg }]);
            setIsProcessingFile(false);
            return;
        }

        const processedContent = await processDocument(fileContent);
        setDocumentPreview({ content: processedContent, id: Date.now().toString() });

    } catch (error) {
        console.error("Error reading or processing file:", error);
        const errorMsg = "Lo siento, ocurrió un error al procesar tu archivo. Por favor, inténtalo de nuevo.";
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'ai', text: errorMsg }]);
    } finally {
        setIsProcessingFile(false);
    }
  };

  const handleAcceptDocument = () => {
    if (!documentPreview) return;
    const docMessage: ChatMessage = {
      id: documentPreview.id,
      role: 'user',
      text: `He adjuntado un documento. Aquí está el resumen en formato de lección:\n\n${documentPreview.content}`
    };
    setMessages(prev => [...prev, docMessage]);
    
    // Trigger AI response to the summarized document
    const prompt = "¡Genial! He organizado el documento para ti. ¿Hay algo específico en esta lección que te gustaría explorar más a fondo o alguna pregunta que tengas al respecto?";
    const aiMessage: ChatMessage = { id: (Date.now() + 1).toString(), role: 'ai', text: prompt };
    setMessages(prev => [...prev, aiMessage]);

    setDocumentPreview(null);
  };

  const handleRejectDocument = () => {
    setDocumentPreview(null);
  };
  
  const handleClearChat = () => {
    setMessages([{ id: 'init', role: 'ai', text: '¡Bienvenido a EduSpark! ¿Cómo puedo ayudarte a aprender hoy?' }]);
    localStorage.removeItem('eduspark-chat-history');
    stopAudio();
  };

  const handleExportChat = () => {
    const chatHistory = messages.map(msg => `${msg.role === 'user' ? 'Tú' : 'EduSpark'}: ${msg.text}`).join('\n\n');
    const blob = new Blob([chatHistory], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'eduspark-chat.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePauseAudio = () => {
    if (speakingMessageId) {
        if (isAudioPaused) {
            audioContextRef.current?.resume();
            setIsAudioPaused(false);
        } else {
            audioContextRef.current?.suspend();
            setIsAudioPaused(true);
        }
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto p-4 font-sans">
      <header className="flex items-center justify-between p-4 border-b border-slate-700">
        <h1 className="text-2xl font-bold text-sky-400">EduSpark Tutor</h1>
        <div className="flex items-center gap-4">
          {capabilities && (
            <select
              value={interactionMode}
              onChange={handleModeChange}
              className="bg-slate-800 border border-slate-700 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-sky-500"
              aria-label="Seleccionar modo de interacción"
            >
              <option value={InteractionMode.SILENT}>Silencioso</option>
              <option value={InteractionMode.HYBRID} disabled={!capabilities.hasMicrophone || !capabilities.hasSpeakers}>Híbrido</option>
              <option value={InteractionMode.AUDIO} disabled={!capabilities.hasMicrophone || !capabilities.hasSpeakers}>Audio</option>
            </select>
          )}
          <button onClick={handleExportChat} className="p-2 hover:bg-slate-700 rounded-full transition-colors" aria-label="Exportar chat">
            <ExportIcon className="w-6 h-6" />
          </button>
          <button onClick={handleClearChat} className="p-2 hover:bg-slate-700 rounded-full transition-colors" aria-label="Limpiar chat">
            <TrashIcon className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
        {messages.map((message) => (
          <div key={message.id} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xl p-4 rounded-2xl ${message.role === 'user' ? 'bg-sky-600 rounded-br-none' : 'bg-slate-700 rounded-bl-none'}`}>
              <p className="whitespace-pre-wrap">{message.text}</p>
              {message.role === 'ai' && message.id !== 'init' && capabilities?.hasSpeakers && (
                <div className="flex gap-2 mt-2">
                   <button onClick={() => speakingMessageId === message.id && !isAudioPaused ? handlePauseAudio() : playAudio(message.text, message.id)} className="p-1 text-slate-300 hover:text-white transition-colors" aria-label={speakingMessageId === message.id && !isAudioPaused ? 'Pausar' : 'Reproducir'}>
                    {speakingMessageId === message.id && !isAudioPaused ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
                  </button>
                  {speakingMessageId === message.id && (
                    <button onClick={stopAudio} className="p-1 text-slate-300 hover:text-white transition-colors" aria-label="Detener">
                      <div className="w-5 h-5 flex items-center justify-center"><div className="w-3 h-3 bg-current rounded-sm"></div></div>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        {isProcessingFile && (
             <div className="flex justify-start gap-3">
                 <div className="max-w-xl p-4 rounded-2xl bg-slate-700 rounded-bl-none flex items-center gap-2">
                     <LoadingSpinner className="w-5 h-5" />
                     <p>Procesando tu documento...</p>
                 </div>
             </div>
        )}
        {documentPreview && (
          <div className="flex justify-start gap-3">
            <div className="max-w-xl p-4 rounded-2xl bg-slate-700 rounded-bl-none border border-sky-500">
                <h3 className="font-bold mb-2">Vista Previa del Documento</h3>
                <div className="max-h-60 overflow-y-auto p-2 bg-slate-800 rounded-md whitespace-pre-wrap mb-4">
                  {documentPreview.content}
                </div>
                <div className="flex justify-end gap-2">
                    <button onClick={handleRejectDocument} className="px-4 py-2 bg-slate-600 hover:bg-slate-500 rounded-md transition-colors">Rechazar</button>
                    <button onClick={handleAcceptDocument} className="px-4 py-2 bg-sky-600 hover:bg-sky-500 rounded-md transition-colors">Aceptar y Enviar</button>
                </div>
            </div>
          </div>
        )}
      </main>

      <footer className="p-4">
        <form onSubmit={handleSubmit} className="flex items-center gap-2 bg-slate-800 rounded-full p-2 border border-slate-700 focus-within:ring-2 focus-within:ring-sky-500">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={isListening ? 'Escuchando...' : 'Escribe tu pregunta...'}
            className="flex-1 bg-transparent px-4 py-2 focus:outline-none disabled:opacity-50"
            disabled={isLoading || isListening || isProcessingFile}
            aria-label="Entrada de chat"
          />
          <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" accept=".txt,.md,.pdf" />
          <button type="button" onClick={handleAttachFile} className="p-2 text-slate-400 hover:text-sky-400 rounded-full transition-colors" aria-label="Adjuntar archivo" disabled={isLoading || isProcessingFile}>
            <AttachmentIcon className="w-6 h-6" />
          </button>
          {interactionMode !== 'SILENT' && capabilities?.hasMicrophone && (
             <button type="button" onClick={toggleListening} className={`p-3 rounded-full transition-colors ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-700 hover:bg-slate-600'}`} aria-label={isListening ? 'Dejar de escuchar' : 'Empezar a escuchar'}>
              <MicrophoneIcon className="w-6 h-6" />
            </button>
          )}
          <button type="submit" className="p-3 bg-sky-600 rounded-full hover:bg-sky-500 transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed" disabled={!inputValue.trim() || isLoading || isProcessingFile} aria-label="Enviar mensaje">
            {isLoading ? <LoadingSpinner className="w-6 h-6" /> : <SendIcon className="w-6 h-6" />}
          </button>
        </form>
      </footer>
    </div>
  );
}
