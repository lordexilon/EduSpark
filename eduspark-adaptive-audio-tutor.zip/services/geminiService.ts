
import { GoogleGenAI, Modality } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const chatModel = 'gemini-2.5-flash';
const proModel = 'gemini-2.5-pro';
const ttsModel = 'gemini-2.5-flash-preview-tts';

const systemInstruction = "Eres EduSpark, un tutor de IA amigable y alentador para una plataforma educativa. Mantén tus respuestas concisas, útiles y atractivas para estudiantes de todas las edades.";

export const getTutorResponse = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: chatModel,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error getting tutor response:", error);
    return "Lo siento, estoy teniendo problemas para conectarme en este momento. Por favor, inténtalo de nuevo más tarde.";
  }
};

export const processDocument = async (fileContent: string): Promise<string> => {
  const prompt = `Eres EduSpark, un tutor de IA. Tu tarea es organizar el siguiente contenido en un formato de lección para una clase. Debes estructurarlo con claridad, utilizando secciones como "Introducción", "Conceptos Clave" (con definiciones), "Ejemplos Prácticos" y un "Resumen" final. El formato debe ser fácil de seguir para un estudiante. Aquí está el contenido:\n\n---\n\n${fileContent}`;
  try {
    const response = await ai.models.generateContent({
      model: proModel,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error processing document:", error);
    return "Lo siento, tuve un problema al procesar el documento. Por favor, asegúrate de que sea un archivo de texto e inténtalo de nuevo.";
  }
};


export const synthesizeSpeech = async (text: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: ttsModel,
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });
    
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return base64Audio;
    }
    return null;
  } catch (error) {
    console.error("Error synthesizing speech:", error);
    return null;
  }
};
