import {
  require_react
} from "./chunk-N7PDAELF.js";
import "./chunk-EWTE5DHJ.js";
export default require_react();
