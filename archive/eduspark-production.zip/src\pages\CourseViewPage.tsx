// pages/CourseViewPage.tsx
// Vista de curso para estudiantes - Muestra módulos y sesiones organizadas

import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { courseService, Course } from '../services/teacherCourses';
import { unitService, CourseUnit } from '../services/teacherCourses';
import { sessionService, Session } from '../services/teacherCourses';
import { materialService, Material } from '../services/teacherCourses';
import { subjectService, careerService, Subject, Career } from '../services/academicService';
import Card from '../components/Card';
import Button from '../components/Button';
import Breadcrumbs from '../components/Breadcrumbs';
import ProgressIndicator from '../components/ProgressIndicator';
import GamificationScore from '../components/GamificationScore';
import { IconBookOpen, IconChevronRight, IconCalendar, IconEye, IconRobot, IconClipboardList, IconClipboardCheck, IconClock, IconCards, IconCheck } from '../components/Icons';
import { MaterialDisplay } from '../components/MaterialDisplay';
import { useAuth } from '../hooks/useAuth';
import { courseEnrollmentService, CourseEnrollment } from '../services/academicService';
import { progressService } from '../services/progressService';
import { quizService, Assessment } from '../services/quizService';
import { VideoTranscriptService } from '../services/videoTranscriptService';
import { supabase } from '../lib/supabase';
import { RichTextDisplay } from '../components/RichTextDisplay';

export const CourseViewPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [course, setCourse] = useState<Course | null>(null);
  const [units, setUnits] = useState<CourseUnit[]>([]);
  const [sessionsByUnit, setSessionsByUnit] = useState<Record<string, Session[]>>({});
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(true);
  const [subject, setSubject] = useState<Subject | null>(null);
  const [career, setCareer] = useState<Career | null>(null);
  const [expandedUnits, setExpandedUnits] = useState<Set<string>>(new Set());
  const [enrollment, setEnrollment] = useState<CourseEnrollment | null>(null);
  const [quizzesByUnit, setQuizzesByUnit] = useState<Record<string, Assessment[]>>({});
  const [generalQuizzes, setGeneralQuizzes] = useState<Assessment[]>([]);
  const [finalExam, setFinalExam] = useState<Assessment | null>(null);
  const [completedUnits, setCompletedUnits] = useState<Set<string>>(new Set());
  const [completedSessions, setCompletedSessions] = useState<Set<string>>(new Set());
  const [completedQuizzes, setCompletedQuizzes] = useState<Set<string>>(new Set());
  const [totalFlashcards, setTotalFlashcards] = useState<number>(0);
  const [completedFlashcards, setCompletedFlashcards] = useState<number>(0);
  const [markingUnit, setMarkingUnit] = useState<string | null>(null);
  const [expandedMaterials, setExpandedMaterials] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (id) {
      loadCourseData();
    }
  }, [id]);

  // Cargar progreso de quizzes después de que se hayan cargado los quizzes
  useEffect(() => {
    const loadQuizProgress = async () => {
      if (!user?.id || !id) return;

      try {
        const allQuizIds = [
          ...Object.values(quizzesByUnit).flat().map(q => q.id),
          ...generalQuizzes.map(q => q.id),
          ...(finalExam ? [finalExam.id] : [])
        ].filter(Boolean);

        if (allQuizIds.length > 0) {
          const { data: quizAttemptsData } = await supabase
            .from('assessment_attempts')
            .select('assessment_id')
            .eq('student_id', user.id)
            .in('assessment_id', allQuizIds)
            .in('status', ['submitted', 'graded']);

          if (quizAttemptsData) {
            const completedQuizIds = new Set(quizAttemptsData.map(qa => qa.assessment_id).filter(Boolean));
            setCompletedQuizzes(completedQuizIds);
          }
        }
      } catch (err) {
        console.error('Error loading quiz progress:', err);
      }
    };

    loadQuizProgress();
  }, [user?.id, id, quizzesByUnit, generalQuizzes, finalExam]);

  const loadCourseData = async () => {
    try {
      setLoading(true);
      const courseId = parseInt(id!);

      const [courseData, unitsData, sessionsData, materialsData] = await Promise.all([
        courseService.getCourse(courseId),
        unitService.getCourseUnits(courseId),
        sessionService.getCourseSessions(courseId),
        materialService.getCourseMaterials(courseId)
      ]);

      setCourse(courseData);
      setUnits(unitsData);
      setMaterials(materialsData);

      // Cargar flashcards del curso
      if (user?.id) {
        try {
          const { getFlashcardsByCourse, getFlashcardsWithProgress } = await import('../services/flashcardService');
          const allFlashcards = await getFlashcardsByCourse(courseId);
          setTotalFlashcards(allFlashcards.length);

          // Obtener flashcards con progreso para contar las dominadas
          if (allFlashcards.length > 0) {
            const flashcardsWithProgress = await getFlashcardsWithProgress(courseId, user.id);
            const masteredCount = flashcardsWithProgress.filter(
              f => f.progress && f.progress.mastery_level >= 4
            ).length;
            setCompletedFlashcards(masteredCount);
          }
        } catch (err) {
          console.warn('Error loading flashcards:', err);
        }
      }

      // Agrupar sesiones por unidad
      const groupedSessions: Record<string, Session[]> = {};
      sessionsData.forEach(session => {
        const unitId = session.unit_id || 'sin-unidad';
        if (!groupedSessions[unitId]) {
          groupedSessions[unitId] = [];
        }
        groupedSessions[unitId].push(session);
      });
      setSessionsByUnit(groupedSessions);

      // Expandir automáticamente la primera unidad
      if (unitsData.length > 0) {
        setExpandedUnits(new Set([unitsData[0].id]));
      }

      // Cargar información académica
      if (courseData?.subject_id) {
        try {
          const subjectData = await subjectService.getSubject(courseData.subject_id);
          setSubject(subjectData);
          if (subjectData?.career_id) {
            const careerData = await careerService.getCareer(subjectData.career_id);
            setCareer(careerData);
          }
        } catch (err) {
          console.error('Error loading academic info:', err);
        }
      }

      // Cargar enrollment del estudiante para obtener progreso
      if (user?.id) {
        try {
          const enrollments = await courseEnrollmentService.getStudentEnrollments(user.id);
          const courseEnrollment = enrollments.find(e => e.course_id === courseId);
          if (courseEnrollment) {
            setEnrollment(courseEnrollment);
          }
        } catch (err) {
          console.error('Error loading enrollment:', err);
        }
      }

      // Cargar quizzes publicados del curso
      try {
        const courseQuizzes = await quizService.getCourseAssessments(courseId, ['quiz', 'trivia', 'exam']);

        // Separar quizzes por unidad, generales (sin unidad) y examen final
        const grouped: Record<string, Assessment[]> = {};
        const general: Assessment[] = [];
        let finalExam: Assessment | null = null;

        courseQuizzes.forEach(quiz => {
          // Si es examen final, guardarlo por separado
          if (quiz.is_final_exam && quiz.assessment_type === 'exam') {
            finalExam = quiz;
          } else if (quiz.unit_id) {
            if (!grouped[quiz.unit_id]) {
              grouped[quiz.unit_id] = [];
            }
            grouped[quiz.unit_id].push(quiz);
          } else {
            // Quizzes generales del curso (sin unidad específica y que no sean examen final)
            general.push(quiz);
          }
        });

        setQuizzesByUnit(grouped);
        setGeneralQuizzes(general);
        setFinalExam(finalExam);
      } catch (err) {
        console.error('Error loading quizzes:', err);
      }

      // Cargar progreso de unidades, sesiones y quizzes completados
      if (user?.id) {
        try {
          // Progreso de unidades
          const { data: unitProgressData } = await supabase
            .from('unit_progress')
            .select('unit_id')
            .eq('student_id', user.id)
            .eq('course_id', courseId)
            .eq('is_completed', true);

          if (unitProgressData) {
            const completedUnitIds = new Set(unitProgressData.map(up => up.unit_id));
            setCompletedUnits(completedUnitIds);
          }

          // Progreso de sesiones
          const { data: sessionProgressData } = await supabase
            .from('session_progress')
            .select('session_id')
            .eq('student_id', user.id)
            .eq('course_id', courseId)
            .eq('is_completed', true);

          if (sessionProgressData) {
            const completedSessionIds = new Set(sessionProgressData.map(sp => sp.session_id).filter(Boolean));
            setCompletedSessions(completedSessionIds);
          }

          // Progreso de quizzes - cargar después de que se hayan cargado los quizzes
          // Esto se hará en un useEffect separado
        } catch (err) {
          console.error('Error loading progress:', err);
        }
      }
    } catch (error) {
      console.error('Error loading course data:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleUnit = (unitId: string) => {
    setExpandedUnits(prev => {
      const newSet = new Set(prev);
      if (newSet.has(unitId)) {
        newSet.delete(unitId);
      } else {
        newSet.add(unitId);
      }
      return newSet;
    });
  };

  // Función auxiliar para detectar si un material es un video
  const isVideoMaterial = (material: Material): boolean => {
    if (material.kind === 'video') return true;
    if (!material.url) return false;
    const transcriptService = new VideoTranscriptService();
    const platform = transcriptService.detectPlatform(material.url);
    return platform !== null;
  };

  // Función helper para normalizar fechas (solo fecha, sin hora, sin zona horaria)
  const normalizeDate = (dateStr: string): Date => {
    // Si la fecha viene como "YYYY-MM-DD", parsearla correctamente
    const parts = dateStr.split('T')[0].split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1; // Los meses en JS son 0-indexed
      const day = parseInt(parts[2], 10);
      return new Date(year, month, day);
    }
    // Si no, usar el constructor normal
    const date = new Date(dateStr);
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
  };

  // Funciones helper para calcular contenido disponible/pendiente
  const isSessionAvailable = (session: Session): boolean => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // Si la sesión tiene fechas, validar contra ellas
    if (session.starts_at && session.ends_at) {
      const startsAt = new Date(session.starts_at);
      const endsAt = new Date(session.ends_at);
      return now >= startsAt && now <= endsAt;
    }
    
    // Si la sesión no tiene fechas, validar contra las fechas del curso (solo fecha, sin hora)
    if (course?.start_date && course?.end_date) {
      const courseStart = normalizeDate(course.start_date);
      const courseEnd = normalizeDate(course.end_date);
      return today >= courseStart && today <= courseEnd;
    }
    
    // Si no hay fechas, considerar disponible
    return true;
  };

  const isUnitAvailable = (unit: CourseUnit): boolean => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // Las unidades validan contra las fechas del curso (solo fecha, sin hora)
    if (course?.start_date && course?.end_date) {
      const courseStart = normalizeDate(course.start_date);
      const courseEnd = normalizeDate(course.end_date);
      return today >= courseStart && today <= courseEnd;
    }
    
    // Si no hay fechas, considerar disponible
    return true;
  };

  // Calcular estadísticas de contenido
  const allSessions = Object.values(sessionsByUnit).flat();
  const availableSessions = allSessions.filter(isSessionAvailable);
  const pendingSessions = allSessions.filter(s => !isSessionAvailable(s));
  const availableUnits = units.filter(isUnitAvailable);
  const pendingUnits = units.filter(u => !isUnitAvailable(u));
  
  // Logs de depuración para estadísticas
  console.log('📊 Estadísticas de contenido:', {
    totalUnits: units.length,
    availableUnits: availableUnits.length,
    pendingUnits: pendingUnits.length,
    totalSessions: allSessions.length,
    availableSessions: availableSessions.length,
    pendingSessions: pendingSessions.length,
    courseStartDate: course?.start_date,
    courseEndDate: course?.end_date,
    today: new Date().toISOString().split('T')[0]
  });

  // Obtener próxima sesión pendiente
  const nextPendingSession = pendingSessions
    .filter(s => s.starts_at && new Date(s.starts_at) > new Date())
    .sort((a, b) => {
      if (!a.starts_at || !b.starts_at) return 0;
      return new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime();
    })[0];

  // Formatear fecha para mostrar
  const formatDate = (dateStr: string | null | undefined): string => {
    if (!dateStr) return '';
    try {
      return new Date(dateStr).toLocaleDateString('es-ES', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateStr;
    }
  };

  const formatDateShort = (dateStr: string | null | undefined): string => {
    if (!dateStr) return '';
    try {
      // Usar normalizeDate para evitar problemas de zona horaria
      const date = normalizeDate(dateStr);
      if (isNaN(date.getTime())) {
        console.warn('Fecha inválida:', dateStr);
        return dateStr;
      }
      return date.toLocaleDateString('es-ES', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
    } catch (error) {
      console.error('Error formateando fecha:', dateStr, error);
      return dateStr;
    }
  };

  // Función para validar si un quiz está disponible según fechas
  const isQuizAvailable = (quiz: Assessment): boolean => {
    // Si el usuario no es estudiante, siempre disponible
    if (user?.role?.name !== 'student') return true;
    
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // PRIORIDAD 1: Si el quiz tiene fechas available_from y available_until, validar contra ellas
    if (quiz.available_from && quiz.available_until) {
      const startDate = new Date(quiz.available_from);
      const endDate = new Date(quiz.available_until);
      return now >= startDate && now <= endDate;
    }
    
    // PRIORIDAD 2: Si solo tiene available_from, validar que ya haya comenzado
    if (quiz.available_from) {
      const startDate = new Date(quiz.available_from);
      if (now < startDate) {
        return false;
      }
      // Si tiene available_from pero no available_until, verificar también fechas del curso
      if (course?.start_date && course?.end_date) {
        const courseStart = normalizeDate(course.start_date);
        const courseEnd = normalizeDate(course.end_date);
        return today >= courseStart && today <= courseEnd;
      }
      return true;
    }
    
    // PRIORIDAD 3: Si solo tiene available_until, validar que no haya finalizado
    if (quiz.available_until) {
      const endDate = new Date(quiz.available_until);
      if (now > endDate) {
        return false;
      }
      // Si tiene available_until pero no available_from, verificar también fechas del curso
      if (course?.start_date && course?.end_date) {
        const courseStart = normalizeDate(course.start_date);
        const courseEnd = normalizeDate(course.end_date);
        return today >= courseStart && today <= courseEnd;
      }
      return true;
    }
    
    // PRIORIDAD 4: Si el quiz está asociado a una sesión, validar fechas de la sesión
    if (quiz.session_id) {
      const session = allSessions.find(s => s.id === quiz.session_id);
      if (session) {
        return isSessionAvailable(session);
      }
    }
    
    // PRIORIDAD 5: Si el quiz está asociado a una unidad, validar fechas del curso
    if (quiz.unit_id) {
      const unit = units.find(u => u.id === quiz.unit_id);
      if (unit) {
        return isUnitAvailable(unit);
      }
    }
    
    // PRIORIDAD 6: Si no tiene fechas ni asociaciones, validar contra fechas del curso (solo fecha, sin hora)
    // IMPORTANTE: Si el curso tiene fechas, el quiz DEBE estar dentro de esas fechas
    if (course?.start_date && course?.end_date) {
      const courseStart = normalizeDate(course.start_date);
      const courseEnd = normalizeDate(course.end_date);
      return today >= courseStart && today <= courseEnd;
    }
    
    // Si el curso no tiene fechas definidas, considerar disponible (comportamiento por defecto)
    return true;
  };

  const toggleMaterials = (unitId: string) => {
    setExpandedMaterials(prev => {
      const newSet = new Set(prev);
      if (newSet.has(unitId)) {
        newSet.delete(unitId);
      } else {
        newSet.add(unitId);
      }
      return newSet;
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="text-center py-8">
        <h2 className="text-xl font-semibold text-gray-900">Curso no encontrado</h2>
        <Button onClick={() => navigate('/my/courses')} className="mt-4">
          Volver a Mis Cursos
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumbs */}
      <Breadcrumbs
        items={[
          { label: 'Dashboard', path: '/dashboard' },
          { label: 'Mis Cursos', path: '/my/courses' },
          { label: course.title }
        ]}
      />

      {/* Header del Curso */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{course.title}</h1>
            {course.code && (
              <p className="text-gray-600 mb-3">Código: {course.code}</p>
            )}
            {course.description && (
              <p className="text-gray-700 mb-4">{course.description}</p>
            )}

            {/* Información Académica */}
            {(subject || career) && (
              <div className="flex flex-wrap gap-4 text-sm mt-4">
                {subject && (
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500">Materia:</span>
                    <span className="font-medium">{subject.name}</span>
                  </div>
                )}
                {career && (
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500">Carrera:</span>
                    <span className="font-medium">{career.name}</span>
                  </div>
                )}
              </div>
            )}

            {/* Indicador de Progreso */}
            {enrollment && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <ProgressIndicator
                  value={enrollment.completion_percentage || 0}
                  label="Progreso del Curso"
                  showIcon={true}
                  size="md"
                  showPercentage={true}
                />
                {enrollment.time_spent_minutes > 0 && (
                  <p className="text-xs text-gray-500 mt-2">
                    Tiempo invertido: {Math.round(enrollment.time_spent_minutes / 60)} horas {enrollment.time_spent_minutes % 60} minutos
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Acciones */}
          <div className="flex gap-2 ml-4 flex-wrap">
            <Link to={`/assignments?courseId=${course.id}`}>
              <Button variant="secondary" leftIcon={<IconClipboardList className="w-5 h-5" />}>
                Ver Tareas
              </Button>
            </Link>
            <Link to={`/sessions?courseId=${course.id}`}>
              <Button variant="secondary" leftIcon={<IconBookOpen className="w-5 h-5" />}>
                Ver Todas las Sesiones
              </Button>
            </Link>
            <Link to={`/tutor?courseId=${course.id}`}>
              <Button variant="primary" leftIcon={<IconRobot className="w-5 h-5" />}>
                Abrir Tutor
              </Button>
            </Link>
            <Link to={`/courses/${course.id}/flashcards`}>
              <Button variant="secondary" leftIcon={<IconCards className="w-5 h-5" />}>
                Estudiar Flashcards
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Banner de Información de Fechas y Calendario */}
      {user?.role?.name === 'student' && (course?.start_date || allSessions.some(s => s.starts_at)) && (
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <div className="p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <IconCalendar className="w-8 h-8 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  📅 Calendario y Disponibilidad del Curso
                </h3>
                
                {/* Información del curso */}
                {course?.start_date && course?.end_date && (
                  <div className="mb-4 p-3 bg-white rounded-lg border border-blue-200">
                    <p className="text-sm text-gray-700 mb-2">
                      <span className="font-semibold">Período del curso:</span>
                    </p>
                    <p className="text-sm text-gray-600">
                      Del {formatDateShort(course.start_date)} al {formatDateShort(course.end_date)}
                    </p>
                    {new Date(course.start_date) > new Date() && (
                      <p className="text-xs text-blue-600 mt-2 font-medium">
                        ⏳ El curso iniciará el {formatDate(course.start_date)}
                      </p>
                    )}
                  </div>
                )}

                {/* Estadísticas de contenido */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="bg-white rounded-lg p-4 border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <IconCheck className="w-5 h-5 text-green-600" />
                      <h4 className="font-semibold text-gray-900">Contenido Disponible</h4>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>✅ {availableUnits.length} de {units.length} unidades disponibles</p>
                      <p>✅ {availableSessions.length} de {allSessions.length} sesiones disponibles</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg p-4 border border-orange-200">
                    <div className="flex items-center gap-2 mb-2">
                      <IconClock className="w-5 h-5 text-orange-600" />
                      <h4 className="font-semibold text-gray-900">Contenido Pendiente</h4>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>⏳ {pendingUnits.length} unidades se habilitarán según fechas</p>
                      <p>⏳ {pendingSessions.length} sesiones se habilitarán según fechas</p>
                      {nextPendingSession && nextPendingSession.starts_at && (
                        <p className="text-xs text-orange-600 font-medium mt-2">
                          Próxima sesión: {formatDateShort(nextPendingSession.starts_at)}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Calendario de sesiones próximas */}
                {pendingSessions.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-semibold text-gray-900 mb-3 text-sm">
                      📆 Próximas Sesiones Programadas
                    </h4>
                    <div className="bg-white rounded-lg border border-blue-200 max-h-64 overflow-y-auto">
                      <div className="divide-y divide-gray-200">
                        {pendingSessions
                          .filter(s => s.starts_at)
                          .sort((a, b) => {
                            if (!a.starts_at || !b.starts_at) return 0;
                            return new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime();
                          })
                          .slice(0, 10)
                          .map((session) => (
                            <div key={session.id} className="p-3 hover:bg-blue-50 transition-colors">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <p className="text-sm font-medium text-gray-900">{session.title}</p>
                                  {session.starts_at && (
                                    <p className="text-xs text-gray-600 mt-1">
                                      <IconCalendar className="w-3 h-3 inline mr-1" />
                                      {formatDate(session.starts_at)}
                                    </p>
                                  )}
                                  {session.ends_at && (
                                    <p className="text-xs text-gray-500 mt-1">
                                      Finaliza: {formatDateShort(session.ends_at)}
                                    </p>
                                  )}
                                </div>
                                <div className="ml-4">
                                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                    Pendiente
                                  </span>
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                    {pendingSessions.filter(s => s.starts_at).length > 10 && (
                      <p className="text-xs text-gray-500 mt-2 text-center">
                        Y {pendingSessions.filter(s => s.starts_at).length - 10} sesiones más...
                      </p>
                    )}
                  </div>
                )}

                {/* Mensaje informativo */}
                <div className="mt-4 p-3 bg-blue-100 rounded-lg border border-blue-300">
                  <p className="text-xs text-blue-900">
                    💡 <strong>Nota:</strong> El contenido se habilita automáticamente según las fechas establecidas. 
                    Las unidades y sesiones estarán disponibles desde su fecha de inicio hasta su fecha de finalización.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Componente de Gamificación con Score */}
      {user && (
        <div className="space-y-4">
          <GamificationScore
            totalUnits={units.length}
            completedUnits={completedUnits.size}
            totalSessions={Object.values(sessionsByUnit).flat().length}
            completedSessions={completedSessions.size}
            totalQuizzes={
              Object.values(quizzesByUnit).flat().filter(isQuizAvailable).length + 
              generalQuizzes.filter(isQuizAvailable).length + 
              (finalExam && isQuizAvailable(finalExam) ? 1 : 0)
            }
            completedQuizzes={completedQuizzes.size}
            totalFlashcards={totalFlashcards}
            completedFlashcards={completedFlashcards}
            overallProgress={enrollment?.completion_percentage || 0}
          />
          <div className="flex justify-end">
            <Link
              to={`/courses/${id}/my-report`}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium"
            >
              <IconRobot className="w-4 h-4" />
              Ver Mi Informe Comprehensivo
            </Link>
          </div>
        </div>
      )}

      {/* Módulos y Sesiones */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-900">Contenido del Curso</h2>

        {units.length === 0 ? (
          <Card>
            <div className="text-center py-8">
              <IconBookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Este curso aún no tiene módulos definidos.</p>
            </div>
          </Card>
        ) : (
          <>
            <p className="text-sm text-gray-500 mb-2">Total de unidades: {units.length}</p>
            {units.map((unit) => {
              const unitSessions = sessionsByUnit[unit.id] || [];
              // Excluir materiales asociados a sesiones (solo mostrar materiales de unidad sin session_id)
              const unitMaterials = materials.filter((material) =>
                material.unit_id === unit.id && !material.session_id
              );
              const isExpanded = expandedUnits.has(unit.id);

              return (
                <Card key={unit.id} className="overflow-hidden">
                  <div
                    className="cursor-pointer p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
                    onClick={() => toggleUnit(unit.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-primary font-semibold text-sm">
                            {unit.number}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">
                            {unit.title}
                          </h3>
                          {unit.description && (
                            <p className="text-sm text-gray-600 mt-1">{unit.description}</p>
                          )}
                          <p className="text-xs text-gray-500 mt-1">
                            {unitSessions.length} {unitSessions.length === 1 ? 'sesión' : 'sesiones'}
                          </p>
                        </div>
                      </div>
                      <IconChevronRight
                        className={`w-5 h-5 text-gray-400 transition-transform ${isExpanded ? 'transform rotate-90' : ''
                          }`}
                      />
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="border-t border-gray-200 p-4 space-y-4">
                      {/* Contenido de la Unidad */}
                      {unit.content_html && (
                        <div className="prose prose-sm max-w-none">
                          <RichTextDisplay content={unit.content_html} />
                        </div>
                      )}
                      {!unit.content_html && unit.content_markdown && (
                        <div className="prose prose-sm max-w-none">
                          <div className="unit-content whitespace-pre-wrap">
                            {unit.content_markdown}
                          </div>
                        </div>
                      )}
                      {!unit.content_html && !unit.content_markdown && unit.description && (
                        <div className="prose prose-sm max-w-none">
                          <p className="text-gray-700">{unit.description}</p>
                        </div>
                      )}

                      {/* Objetivos de Aprendizaje */}
                      {unit.learning_objectives && unit.learning_objectives.length > 0 && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <h4 className="text-sm font-semibold text-blue-900 mb-2">
                            Objetivos de Aprendizaje
                          </h4>
                          <ul className="list-disc list-inside space-y-1">
                            {unit.learning_objectives.map((objective, idx) => (
                              <li key={idx} className="text-sm text-blue-800">{objective}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Sesiones - Mejorada jerarquía visual - Ahora aparecen después de los objetivos */}
                      {unitSessions.length > 0 && (
                        <div className="border-l-4 border-blue-300 bg-blue-50/50 rounded-r-lg p-4 space-y-3">
                          <div className="flex items-center gap-2 mb-2">
                            <IconBookOpen className="w-5 h-5 text-blue-600" />
                            <h4 className="text-base font-semibold text-gray-900">
                              Sesiones de esta Unidad ({unitSessions.length})
                            </h4>
                          </div>
                          <p className="text-xs text-gray-600 mb-3">
                            Estas sesiones forman parte de la unidad "{unit.title}". Haz clic en cada una para acceder al contenido.
                          </p>
                          <div className="space-y-2 ml-2">
                            {unitSessions
                              .sort((a, b) => {
                                // Ordenar por order_index si existe, sino por fecha
                                if (a.order_index !== null && b.order_index !== null) {
                                  return a.order_index - b.order_index;
                                }
                                if (a.starts_at && b.starts_at) {
                                  return new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime();
                                }
                                return 0;
                              })
                              .map((session, index) => (
                                <Link
                                  key={session.id}
                                  to={`/session/${session.id}`}
                                  className="block p-3 bg-white border-l-2 border-blue-400 rounded-r-lg hover:border-blue-600 hover:bg-blue-50 transition-all group shadow-sm"
                                >
                                  <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2 mb-1">
                                        <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center text-xs font-semibold">
                                          {index + 1}
                                        </span>
                                        <h5 className="text-sm font-semibold text-gray-900 group-hover:text-blue-700">
                                          {session.title}
                                        </h5>
                                      </div>
                                      {session.description && (
                                        <p className="text-xs text-gray-600 line-clamp-2 mb-2 ml-8">
                                          {session.description}
                                        </p>
                                      )}
                                      {session.starts_at && (
                                        <div className="flex items-center gap-1 text-xs text-gray-500 ml-8">
                                          <IconCalendar className="w-3 h-3" />
                                          <span>
                                            {new Date(session.starts_at).toLocaleDateString('es-ES', {
                                              weekday: 'long',
                                              year: 'numeric',
                                              month: 'long',
                                              day: 'numeric'
                                            })}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                    <IconChevronRight className="w-5 h-5 text-gray-400 group-hover:text-blue-600 transition-colors flex-shrink-0 ml-3" />
                                  </div>
                                </Link>
                              ))}
                          </div>
                        </div>
                      )}

                      {/* Botón de "Entendido" */}
                      {(() => {
                        const isCompleted = completedUnits.has(unit.id);
                        const isMarking = markingUnit === unit.id;
                        const unitAvailable = isUnitAvailable(unit);

                        return (
                          <div className={`border rounded-lg p-4 transition-colors ${isCompleted
                            ? 'bg-green-100 border-green-300'
                            : unitAvailable
                              ? 'bg-green-50 border-green-200'
                              : 'bg-gray-50 border-gray-200'
                            }`}>
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <h4 className={`text-sm font-semibold mb-1 flex items-center gap-2 ${isCompleted ? 'text-green-800' : unitAvailable ? 'text-green-900' : 'text-gray-600'
                                  }`}>
                                  {isCompleted && <IconCheck className="w-5 h-5 text-green-600" />}
                                  {isCompleted ? '¡Contenido Leído!' : unitAvailable ? '¡Contenido Leído!' : 'Contenido Pendiente'}
                                </h4>
                                <p className={`text-xs ${isCompleted ? 'text-green-800' : unitAvailable ? 'text-green-700' : 'text-gray-600'
                                  }`}>
                                  {isCompleted
                                    ? 'Esta unidad ya fue marcada como leída. Tu comprensión se evaluará en las actividades y tareas del curso.'
                                    : unitAvailable
                                      ? 'Marca esta unidad como leída. Tu comprensión se evaluará en las actividades y tareas del curso.'
                                      : 'Esta unidad estará disponible cuando el curso inicie según las fechas establecidas.'
                                  }
                                </p>
                              </div>
                              <button
                                onClick={async () => {
                                  if (!user?.id || isCompleted || isMarking || !unitAvailable) return;
                                  setMarkingUnit(unit.id);
                                  try {
                                    // Marcar unidad como accedida (método simplificado)
                                    await progressService.completeSession(
                                      user.id,
                                      unit.id,
                                      parseInt(id!),
                                      unit.id,
                                      { timeSpentMinutes: 15 }
                                    );
                                    // Actualizar estado local inmediatamente
                                    setCompletedUnits(prev => new Set(prev).add(unit.id));
                                  } catch (err) {
                                    console.error('Error:', err);
                                    alert('Error al marcar la unidad como leída');
                                  } finally {
                                    setMarkingUnit(null);
                                  }
                                }}
                                disabled={isCompleted || isMarking || !unitAvailable}
                                className={`ml-4 px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${isCompleted
                                  ? 'bg-green-500 text-white cursor-not-allowed opacity-75'
                                  : !unitAvailable
                                    ? 'bg-gray-400 text-white cursor-not-allowed opacity-50'
                                    : isMarking
                                      ? 'bg-green-400 text-white cursor-wait'
                                      : 'bg-green-600 hover:bg-green-700 text-white'
                                  }`}
                              >
                                {isMarking ? (
                                  <>
                                    <span className="animate-spin">⏳</span>
                                    Procesando...
                                  </>
                                ) : isCompleted ? (
                                  <>
                                    <IconCheck className="w-4 h-4" />
                                    Leído ✓
                                  </>
                                ) : (
                                  <>
                                    <IconCheck className="w-4 h-4" />
                                    Entendido ✓
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        );
                      })()}

                      {/* Quizzes/Evaluaciones - Mejorada jerarquía visual */}
                      {(() => {
                        const unitQuizzes = (quizzesByUnit[unit.id] || []).filter(isQuizAvailable);
                        if (unitQuizzes.length === 0) return null;

                        const typeLabels: Record<string, string> = {
                          'quiz': 'Quiz',
                          'trivia': 'Trivia',
                          'exam': 'Examen',
                          'project': 'Proyecto',
                          'assignment': 'Tarea'
                        };
                        const typeColors: Record<string, string> = {
                          'quiz': 'bg-blue-100 text-blue-700 border-blue-300',
                          'trivia': 'bg-purple-100 text-purple-700 border-purple-300',
                          'exam': 'bg-red-100 text-red-700 border-red-300',
                          'project': 'bg-green-100 text-green-700 border-green-300',
                          'assignment': 'bg-yellow-100 text-yellow-700 border-yellow-300'
                        };

                        return (
                          <div className="border-l-4 border-purple-300 bg-purple-50/50 rounded-r-lg p-4 space-y-3 mb-4">
                            <div className="flex items-center gap-2 mb-2">
                              <IconClipboardCheck className="w-5 h-5 text-purple-600" />
                              <h4 className="text-base font-semibold text-gray-900">
                                Evaluaciones de esta Unidad ({unitQuizzes.length})
                              </h4>
                            </div>
                            <p className="text-xs text-gray-600 mb-3">
                              Estas evaluaciones forman parte de la unidad "{unit.title}". Completa estas actividades para medir tu comprensión del contenido.
                            </p>
                            <div className="space-y-2 ml-2">
                              {unitQuizzes.map((quiz, index) => (
                                <Link
                                  key={quiz.id}
                                  to={`/quiz/${quiz.id}`}
                                  className={`block p-3 bg-white border-l-2 rounded-r-lg hover:shadow-md transition-all group shadow-sm ${typeColors[quiz.assessment_type]?.split(' ')[2] || 'border-gray-300'
                                    } hover:border-opacity-100`}
                                  style={{
                                    borderLeftColor: typeColors[quiz.assessment_type]?.includes('blue') ? '#93c5fd' :
                                      typeColors[quiz.assessment_type]?.includes('purple') ? '#c4b5fd' :
                                        typeColors[quiz.assessment_type]?.includes('red') ? '#fca5a5' :
                                          typeColors[quiz.assessment_type]?.includes('green') ? '#86efac' :
                                            typeColors[quiz.assessment_type]?.includes('yellow') ? '#fde047' : '#d1d5db'
                                  }}
                                >
                                  <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                                        <span className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold ${typeColors[quiz.assessment_type] || 'bg-gray-100 text-gray-700'
                                          }`}>
                                          {index + 1}
                                        </span>
                                        <h5 className="text-sm font-semibold text-gray-900 group-hover:text-purple-700">
                                          {quiz.title}
                                        </h5>
                                        <span className={`text-xs font-medium px-2 py-0.5 rounded ${typeColors[quiz.assessment_type] || 'bg-gray-100 text-gray-700'
                                          }`}>
                                          {typeLabels[quiz.assessment_type] || quiz.assessment_type}
                                        </span>
                                      </div>
                                      {quiz.description && (
                                        <p className="text-xs text-gray-600 line-clamp-2 mb-2 ml-8">
                                          {quiz.description}
                                        </p>
                                      )}
                                      <div className="flex items-center gap-3 text-xs text-gray-500 flex-wrap ml-8">
                                        {quiz.time_limit && (
                                          <div className="flex items-center gap-1">
                                            <IconClock className="w-3 h-3" />
                                            <span>{quiz.time_limit} min</span>
                                          </div>
                                        )}
                                        {quiz.max_attempts && (
                                          <span>{quiz.max_attempts} intento{quiz.max_attempts > 1 ? 's' : ''}</span>
                                        )}
                                        {quiz.passing_score && (
                                          <span>Aprobar: {quiz.passing_score}%</span>
                                        )}
                                      </div>
                                    </div>
                                    <IconChevronRight className="w-5 h-5 text-gray-400 group-hover:text-purple-600 transition-colors flex-shrink-0 ml-3" />
                                  </div>
                                </Link>
                              ))}
                            </div>
                          </div>
                        );
                      })()}

                      {/* Videos de la Unidad - Con plegado/desplegado */}
                      {unitMaterials.filter(isVideoMaterial).length > 0 && (
                        <div className="space-y-4 mb-4">
                          <button
                            onClick={() => toggleMaterials(`videos-${unit.id}`)}
                            className="flex items-center justify-between w-full p-3 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                          >
                            <h4 className="text-sm font-semibold text-gray-900">
                              Videos ({unitMaterials.filter(isVideoMaterial).length})
                            </h4>
                            <IconChevronRight
                              className={`w-5 h-5 text-gray-400 transition-transform ${expandedMaterials.has(`videos-${unit.id}`) ? 'transform rotate-90' : ''}`}
                            />
                          </button>
                          {expandedMaterials.has(`videos-${unit.id}`) && (
                            <div className="space-y-6 mt-3">
                              {unitMaterials.filter(isVideoMaterial).map((material) => (
                                <div key={material.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                  <MaterialDisplay
                                    material={material}
                                    showFullPlayer={true}
                                  />
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Otros Materiales de la Unidad - Con plegado/desplegado */}
                      {unitMaterials.filter(m => !isVideoMaterial(m)).length > 0 && (
                        <div className="space-y-2">
                          <button
                            onClick={() => toggleMaterials(`materials-${unit.id}`)}
                            className="flex items-center justify-between w-full p-3 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                          >
                            <h4 className="text-sm font-semibold text-gray-900">
                              Material de la unidad ({unitMaterials.filter(m => !isVideoMaterial(m)).length})
                            </h4>
                            <IconChevronRight
                              className={`w-5 h-5 text-gray-400 transition-transform ${expandedMaterials.has(`materials-${unit.id}`) ? 'transform rotate-90' : ''}`}
                            />
                          </button>
                          {expandedMaterials.has(`materials-${unit.id}`) && (
                            <div className="space-y-2 mt-3">
                              {unitMaterials.filter(m => !isVideoMaterial(m)).map((material) => (
                                <MaterialDisplay
                                  key={material.id}
                                  material={material}
                                  showFullPlayer={false}
                                />
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              );
            })}
          </>
        )
        }

        {/* Sesiones sin módulo asignado */}
        {
          sessionsByUnit['sin-unidad'] && sessionsByUnit['sin-unidad'].length > 0 && (
            <Card>
              <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  Sesiones sin Módulo
                </h3>
                <div className="space-y-2">
                  {sessionsByUnit['sin-unidad'].map((session) => (
                    <Link
                      key={session.id}
                      to={`/session/${session.id}`}
                      className="block p-3 bg-white border border-gray-200 rounded-lg hover:border-primary hover:bg-primary/5 transition-all"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="text-sm font-semibold text-gray-900">{session.title}</h4>
                          {session.description && (
                            <p className="text-xs text-gray-600 mt-1">{session.description}</p>
                          )}
                        </div>
                        <IconEye className="w-5 h-5 text-gray-400" />
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </Card>
          )
        }
      </div >

      {/* Evaluaciones Generales del Curso (sin unidad específica) */}
      {
        generalQuizzes.filter(isQuizAvailable).length > 0 && (
          <Card className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Evaluaciones Generales</h2>
            <div className="space-y-2">
              {generalQuizzes.filter(isQuizAvailable).map((quiz) => {
                const typeLabels: Record<string, string> = {
                  'quiz': 'Quiz',
                  'trivia': 'Trivia',
                  'exam': 'Examen',
                  'project': 'Proyecto',
                  'assignment': 'Tarea'
                };
                const typeColors: Record<string, string> = {
                  'quiz': 'bg-blue-100 text-blue-700',
                  'trivia': 'bg-purple-100 text-purple-700',
                  'exam': 'bg-red-100 text-red-700',
                  'project': 'bg-green-100 text-green-700',
                  'assignment': 'bg-yellow-100 text-yellow-700'
                };

                return (
                  <Link
                    key={quiz.id}
                    to={`/quiz/${quiz.id}`}
                    className="block p-4 bg-white border border-gray-200 rounded-lg hover:border-primary hover:bg-primary/5 transition-all group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <IconClipboardCheck className="w-5 h-5 text-primary flex-shrink-0" />
                          <h4 className="text-base font-semibold text-gray-900 group-hover:text-primary">
                            {quiz.title}
                          </h4>
                          <span className={`text-xs font-medium px-2 py-1 rounded ${typeColors[quiz.assessment_type] || 'bg-gray-100 text-gray-700'}`}>
                            {typeLabels[quiz.assessment_type] || quiz.assessment_type}
                          </span>
                        </div>
                        {quiz.description && (
                          <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                            {quiz.description}
                          </p>
                        )}
                        <div className="flex items-center gap-3 text-xs text-gray-500 flex-wrap">
                          {quiz.time_limit && (
                            <div className="flex items-center gap-1">
                              <IconClock className="w-3 h-3" />
                              <span>{quiz.time_limit} minutos</span>
                            </div>
                          )}
                          {quiz.max_attempts && (
                            <span>{quiz.max_attempts} intento{quiz.max_attempts > 1 ? 's' : ''}</span>
                          )}
                          {!quiz.max_attempts && (
                            <span className="text-green-600 font-medium">Intentos ilimitados</span>
                          )}
                          {quiz.passing_score && (
                            <span>Aprobar: {quiz.passing_score}%</span>
                          )}
                        </div>
                      </div>
                      <IconChevronRight className="w-5 h-5 text-gray-400 group-hover:text-primary transition-colors flex-shrink-0 ml-3" />
                    </div>
                  </Link>
                );
              })}
            </div>
          </Card>
        )
      }

      {/* Examen Final */}
      {
        finalExam && finalExam.is_published && finalExam.is_active && isQuizAvailable(finalExam) && (
          <Card className="mb-6 border-2 border-red-200 bg-red-50">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-shrink-0 w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <IconClipboardCheck className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-red-900">Examen Final</h2>
                  <p className="text-sm text-red-700 mt-1">
                    Evaluación final del curso
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-lg p-4 border border-red-200 mb-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {finalExam.title}
                    </h3>
                    {finalExam.description && (
                      <p className="text-sm text-gray-600 mb-3">
                        {finalExam.description}
                      </p>
                    )}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                      {finalExam.time_limit && (
                        <span className="flex items-center gap-1">
                          <IconClock className="w-4 h-4" />
                          {finalExam.time_limit} minutos
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <IconClipboardList className="w-4 h-4" />
                        {finalExam.total_points} puntos
                      </span>
                      {finalExam.passing_score && (
                        <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium">
                          Aprobación: {finalExam.passing_score}%
                        </span>
                      )}
                      {finalExam.max_attempts && (
                        <span className="text-xs text-gray-500">
                          Máximo {finalExam.max_attempts} {finalExam.max_attempts === 1 ? 'intento' : 'intentos'}
                        </span>
                      )}
                    </div>
                    {finalExam.instructions && (
                      <div className="mt-3 p-3 bg-gray-50 rounded border border-gray-200">
                        <p className="text-xs font-medium text-gray-700 mb-1">Instrucciones:</p>
                        <p className="text-xs text-gray-600 whitespace-pre-wrap">
                          {finalExam.instructions}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <Link to={`/quiz/${finalExam.id}`}>
                <Button
                  variant="primary"
                  className="w-full"
                  leftIcon={<IconClipboardCheck className="w-5 h-5" />}
                >
                  Realizar Examen Final
                </Button>
              </Link>
            </div>
          </Card>
        )
      }

      {/* Materiales generales del curso (sin unidad y sin sesión) */}
      {
        materials.filter((material) => !material.unit_id && !material.session_id).length > 0 && (
          <div className="space-y-3">
            <h2 className="text-xl font-semibold text-gray-900">Materiales del Curso</h2>

            {/* Videos generales del curso (sin unidad y sin sesión) - Con plegado/desplegado */}
            {materials.filter((material) => !material.unit_id && !material.session_id && isVideoMaterial(material)).length > 0 && (
              <Card className="mb-4">
                <div className="p-4">
                  <button
                    onClick={() => toggleMaterials('course-videos')}
                    className="flex items-center justify-between w-full mb-4"
                  >
                    <h3 className="text-lg font-semibold text-gray-900">
                      Videos del Curso ({materials.filter((material) => !material.unit_id && !material.session_id && isVideoMaterial(material)).length})
                    </h3>
                    <IconChevronRight
                      className={`w-5 h-5 text-gray-400 transition-transform ${expandedMaterials.has('course-videos') ? 'transform rotate-90' : ''}`}
                    />
                  </button>
                  {expandedMaterials.has('course-videos') && (
                    <div className="space-y-6">
                      {materials
                        .filter((material) => !material.unit_id && !material.session_id && isVideoMaterial(material))
                        .map((material) => (
                          <div key={material.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                            <MaterialDisplay
                              material={material}
                              showFullPlayer={true}
                            />
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </Card>
            )}

            {/* Otros materiales generales del curso (sin unidad y sin sesión) - Con plegado/desplegado */}
            {materials.filter((material) => !material.unit_id && !material.session_id && !isVideoMaterial(material)).length > 0 && (
              <Card>
                <div className="p-4">
                  <button
                    onClick={() => toggleMaterials('course-materials')}
                    className="flex items-center justify-between w-full mb-4"
                  >
                    <h3 className="text-lg font-semibold text-gray-900">
                      Material del curso ({materials.filter((material) => !material.unit_id && !material.session_id && !isVideoMaterial(material)).length})
                    </h3>
                    <IconChevronRight
                      className={`w-5 h-5 text-gray-400 transition-transform ${expandedMaterials.has('course-materials') ? 'transform rotate-90' : ''}`}
                    />
                  </button>
                  {expandedMaterials.has('course-materials') && (
                    <div className="space-y-2">
                      {materials
                        .filter((material) => !material.unit_id && !material.session_id && !isVideoMaterial(material))
                        .map((material) => (
                          <MaterialDisplay
                            key={material.id}
                            material={material}
                            showFullPlayer={false}
                          />
                        ))}
                    </div>
                  )}
                </div>
              </Card>
            )}
          </div>
        )
      }
    </div >
  );
};

export default CourseViewPage;

