const { createClient } = require('@supabase/supabase-js');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const pdfParse = require('pdf-parse');
const axios = require('axios');

// Inicializar clientes
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
);

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Configuración para archivos grandes (hasta 900MB)
const MAX_FILE_SIZE = 900 * 1024 * 1024; // 900MB
const DOWNLOAD_TIMEOUT = 1800000; // 30 minutos para descarga de archivos grandes
const PARSE_TIMEOUT = 600000; // 10 minutos para extracción de texto
const PROCESSING_TIMEOUT = 3600000; // 60 minutos para procesamiento total

/**
 * Cloud Function principal - Procesa jobs de RAG
 */
exports.processRagJobs = async (req, res) => {
    console.log('[RAG Worker] Iniciando procesamiento...');

    let job = null; // Declarar fuera para acceso en catch

    try {
        // 1. Obtener jobs pendientes
        const { data: jobs, error: jobsError } = await supabase
            .from('file_processing_jobs')
            .select('*')
            .eq('status', 'pending')
            .order('created_at', { ascending: true })
            .limit(1);

        if (jobsError) throw jobsError;

        if (!jobs || jobs.length === 0) {
            console.log('[RAG Worker] No hay jobs pendientes');
            return res.status(200).json({ success: true, message: 'No pending jobs' });
        }

        job = jobs[0];
        console.log(`[RAG Worker] ========================================`);
        console.log(`[RAG Worker] 🚀 INICIANDO PROCESAMIENTO DE JOB`);
        console.log(`[RAG Worker] Job ID: ${job.id}`);
        console.log(`[RAG Worker] Archivo: ${job.file_name}`);
        console.log(`[RAG Worker] Usuario: ${job.user_id}`);
        console.log(`[RAG Worker] Creado: ${job.created_at}`);
        console.log(`[RAG Worker] ========================================`);

        // 2. Marcar como processing y actualizar startedAt
        const startedAt = new Date().toISOString();
        const { error: updateError } = await supabase
            .from('file_processing_jobs')
            .update({ 
                status: 'processing', 
                updated_at: startedAt,
                metadata: {
                    ...job.metadata,
                    startedAt: startedAt
                }
            })
            .eq('id', job.id);
        
        if (updateError) {
            console.error(`[RAG Worker] ❌ Error actualizando estado a processing:`, updateError);
            throw updateError;
        }
        
        console.log(`[RAG Worker] ✅ Job marcado como 'processing'`);

        // 2.5. Obtener información del material para saber dónde guardar los chunks
        let materialInfo = null;
        if (job.metadata?.materialId) {
            console.log(`[RAG Worker] 📋 Obteniendo información del material ${job.metadata.materialId}...`);
            const { data: materialData, error: materialFetchError } = await supabase
                .from('materials')
                .select('course_id, unit_id, session_id')
                .eq('id', job.metadata.materialId)
                .single();
            
            if (materialFetchError) {
                console.error(`[RAG Worker] ❌ Error obteniendo información del material:`, materialFetchError);
                throw new Error(`Error obteniendo información del material: ${materialFetchError.message}`);
            }
            
            if (!materialData) {
                throw new Error(`Material ${job.metadata.materialId} no encontrado`);
            }
            
            materialInfo = materialData;
            console.log(`[RAG Worker] 📋 Material encontrado:`, {
                materialId: job.metadata.materialId,
                course_id: materialInfo.course_id,
                unit_id: materialInfo.unit_id,
                session_id: materialInfo.session_id
            });
        } else {
            throw new Error('No se proporcionó materialId en los metadatos del job. El job debe tener un materialId para procesar chunks.');
        }

        // 3. Descargar PDF con timeout y validación de tamaño
        let pdfBuffer;

        console.log(`[RAG Worker] Iniciando descarga del archivo...`);

        // Determinar la fuente del archivo
        // Si metadata.source es 'google_drive' o si bucket_path parece ser un ID de Google Drive (no contiene '/')
        const isGoogleDrive = job.metadata?.source === 'google_drive' || 
                              (!job.bucket_path?.includes('/') && job.metadata?.driveFileId);
        
        if (isGoogleDrive) {
            // Descargar desde Google Drive
            const driveFileId = job.metadata?.driveFileId || job.bucket_path || job.metadata?.sourceFileId;
            const userId = job.metadata?.userId || job.user_id;

            if (!driveFileId) {
                throw new Error('No se encontró el ID del archivo de Google Drive. Verifica que metadata.driveFileId o bucket_path estén configurados.');
            }

            if (!userId) {
                throw new Error('No se encontró el ID del usuario. Verifica que metadata.userId o user_id estén configurados.');
            }

            console.log(`[RAG Worker] 📥 Descargando desde Google Drive:`);
            console.log(`[RAG Worker]    - File ID: ${driveFileId}`);
            console.log(`[RAG Worker]    - User ID: ${userId}`);

            // Obtener token del usuario
            const { data: tokenData, error: tokenError } = await supabase
                .from('user_google_tokens')
                .select('access_token, refresh_token, expires_at')
                .eq('user_id', userId)
                .in('service_type', ['drive', 'both'])
                .single();

            if (tokenError || !tokenData) {
                console.error(`[RAG Worker] ❌ Error obteniendo token de Google Drive:`, tokenError);
                throw new Error(`No se encontró token de Google Drive para el usuario ${userId}. El usuario debe conectar su cuenta de Google Drive primero.`);
            }

            // Verificar si el token está expirado
            if (tokenData.expires_at && new Date(tokenData.expires_at) < new Date()) {
                console.warn(`[RAG Worker] ⚠️ Token expirado, pero intentando usar de todas formas...`);
            }

            // Descargar archivo de Drive con timeout
            console.log(`[RAG Worker] Descargando archivo desde Google Drive API...`);
            try {
                const response = await axios.get(
                    `https://www.googleapis.com/drive/v3/files/${driveFileId}?alt=media`,
                    {
                        headers: { Authorization: `Bearer ${tokenData.access_token}` },
                        responseType: 'arraybuffer',
                        timeout: DOWNLOAD_TIMEOUT,
                        maxContentLength: MAX_FILE_SIZE,
                        maxBodyLength: MAX_FILE_SIZE
                    }
                );

                pdfBuffer = Buffer.from(response.data);
                console.log(`[RAG Worker] ✅ Archivo descargado exitosamente desde Google Drive`);
            } catch (downloadErr) {
                console.error(`[RAG Worker] ❌ Error descargando desde Google Drive:`, downloadErr.message);
                if (downloadErr.response?.status === 401) {
                    throw new Error('Token de Google Drive inválido o expirado. El usuario debe reconectar su cuenta de Google Drive.');
                } else if (downloadErr.response?.status === 404) {
                    throw new Error(`Archivo no encontrado en Google Drive (ID: ${driveFileId}). Verifica que el archivo exista y sea accesible.`);
                } else if (downloadErr.response?.status === 403) {
                    throw new Error('Sin permisos para acceder al archivo en Google Drive. Verifica los permisos del archivo.');
                }
                throw new Error(`Error descargando archivo desde Google Drive: ${downloadErr.message}`);
            }

        } else {
            // Descargar desde Supabase Storage
            console.log(`[RAG Worker] 📥 Descargando desde Supabase Storage:`);
            console.log(`[RAG Worker]    - Bucket: course-documents`);
            console.log(`[RAG Worker]    - Path: ${job.bucket_path}`);
            
            if (!job.bucket_path) {
                throw new Error('No se especificó bucket_path para descargar desde Supabase Storage');
            }
            
            // Crear timeout para la descarga
            const downloadPromise = supabase.storage
                .from('course-documents')
                .download(job.bucket_path);

            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error(`Timeout: La descarga del archivo tardó más de ${DOWNLOAD_TIMEOUT / 60000} minutos`)), DOWNLOAD_TIMEOUT);
            });

            try {
                const result = await Promise.race([
                    downloadPromise,
                    timeoutPromise
                ]);

                const { data: fileData, error: downloadError } = result;

                if (downloadError) {
                    console.error(`[RAG Worker] ❌ Error descargando desde Supabase Storage:`, downloadError);
                    throw downloadError;
                }

                if (!fileData) {
                    throw new Error('No se recibieron datos del archivo desde Supabase Storage');
                }

                pdfBuffer = Buffer.from(await fileData.arrayBuffer());
                console.log(`[RAG Worker] ✅ Archivo descargado exitosamente desde Supabase Storage`);
            } catch (err) {
                if (err.message?.includes('Timeout')) {
                    throw err;
                }
                console.error(`[RAG Worker] ❌ Error en descarga desde Supabase Storage:`, err);
                throw new Error(`Error descargando archivo desde Supabase Storage: ${err.message || err}`);
            }
        }

        const actualFileSizeMB = pdfBuffer.length / (1024 * 1024);
        console.log(`[RAG Worker] PDF descargado: ${pdfBuffer.length} bytes (${actualFileSizeMB.toFixed(2)} MB)`);

        // Validar tamaño del archivo
        if (pdfBuffer.length > MAX_FILE_SIZE) {
            throw new Error(`Archivo demasiado grande: ${actualFileSizeMB.toFixed(2)}MB. El límite máximo es ${MAX_FILE_SIZE / (1024 * 1024)}MB.`);
        }

        // 4. Validar que el archivo sea un PDF válido antes de procesar
        console.log(`[RAG Worker] Validando formato PDF...`);
        const pdfHeader = pdfBuffer.slice(0, 4).toString();
        if (pdfHeader !== '%PDF') {
            throw new Error('El archivo no es un PDF válido. El archivo puede estar corrupto o no ser un PDF.');
        }

        // 4. Extraer texto del PDF con manejo de errores mejorado
        console.log(`[RAG Worker] Extrayendo texto del PDF (esto puede tardar varios minutos para archivos grandes de ${actualFileSizeMB.toFixed(2)}MB)...`);
        
        let pdfData;
        try {
            // Añadir timeout para la extracción de texto (más tiempo para archivos grandes)
            const parsePromise = pdfParse(pdfBuffer, {
                // Opciones para archivos grandes: procesar en modo más eficiente
                max: 0, // Sin límite de páginas
                version: 'v1.10.100'
            });
            const parseTimeout = new Promise((_, reject) => {
                setTimeout(() => reject(new Error('Timeout: La extracción de texto tardó más de 10 minutos')), PARSE_TIMEOUT);
            });

            pdfData = await Promise.race([parsePromise, parseTimeout]);
        } catch (parseError) {
            // Detectar diferentes tipos de errores de PDF
            const errorMessage = parseError.message || parseError.toString();
            const errorStack = parseError.stack || '';
            
            console.error('[RAG Worker] Error parseando PDF:', errorMessage);
            console.error('[RAG Worker] Stack:', errorStack);
            
            if (parseError.message?.includes('Timeout') || errorMessage.includes('Timeout')) {
                throw new Error(`El archivo es muy grande (${actualFileSizeMB.toFixed(2)}MB) y la extracción de texto está tardando demasiado. Considera comprimir el PDF o dividirlo en partes más pequeñas.`);
            }
            
            // Detectar PDF inválido o corrupto
            if (errorMessage.includes('InvalidPDF') || 
                errorMessage.includes('Invalid PDF') || 
                errorMessage.includes('InvalidPDFException') ||
                errorStack.includes('InvalidPDF') ||
                errorMessage.includes('corrupt') ||
                errorMessage.includes('malformed')) {
                throw new Error(`El PDF está corrupto o es inválido. Por favor, verifica que el archivo no esté dañado. Si el archivo se descargó desde Google Drive, intenta descargarlo nuevamente o subirlo directamente desde tu computadora.`);
            }
            
            // Detectar errores de formato
            if (errorMessage.includes('format') || errorMessage.includes('Format')) {
                throw new Error(`El archivo no tiene un formato PDF válido. Verifica que el archivo sea realmente un PDF y no esté corrupto.`);
            }
            
            // Error genérico con más contexto
            throw new Error(`Error extrayendo texto del PDF: ${errorMessage}. El archivo puede estar corrupto, ser una imagen escaneada sin OCR, o tener un formato no soportado.`);
        }

        const fullText = pdfData.text;

        if (!fullText || fullText.trim().length === 0) {
            throw new Error('No se pudo extraer texto del PDF. El archivo puede estar corrupto, ser una imagen escaneada sin OCR, o tener texto protegido. Intenta usar un PDF con texto seleccionable.');
        }

        console.log(`[RAG Worker] Texto extraído: ${fullText.length} caracteres (${(fullText.length / 1024).toFixed(2)} KB)`);

        // 5. Dividir en chunks (optimizado para archivos grandes)
        const chunkSize = 30000;
        const chunks = [];
        const totalChunks = Math.ceil(fullText.length / chunkSize);
        
        console.log(`[RAG Worker] Dividiendo texto en chunks (tamaño: ${chunkSize} caracteres, estimado: ~${totalChunks} chunks)...`);
        
        for (let i = 0; i < fullText.length; i += chunkSize) {
            chunks.push(fullText.substring(i, i + chunkSize));
            // Log cada 100 chunks para archivos muy grandes
            if (chunks.length % 100 === 0) {
                console.log(`[RAG Worker] Procesados ${chunks.length}/${totalChunks} chunks...`);
            }
        }

        console.log(`[RAG Worker] Creados ${chunks.length} chunks (${(fullText.length / 1024 / 1024).toFixed(2)} MB de texto)`);

        // 6. Generar embeddings y guardar (optimizado para archivos grandes)
        const model = genAI.getGenerativeModel({ model: 'text-embedding-004' });
        
        console.log(`[RAG Worker] Generando embeddings para ${chunks.length} chunks (esto puede tardar varios minutos)...`);

        // Establecer chunksTotal al inicio del procesamiento
        try {
            await supabase
                .from('file_processing_jobs')
                .update({
                    metadata: {
                        ...job.metadata,
                        chunksTotal: chunks.length,
                        chunksProcessed: 0
                    },
                    updated_at: new Date().toISOString()
                })
                .eq('id', job.id);
            console.log(`[RAG Worker] 📊 Progreso inicial establecido: 0/${chunks.length} chunks`);
        } catch (updateError) {
            console.warn('[RAG Worker] ⚠️ Error estableciendo progreso inicial (no crítico):', updateError.message);
        }

        // Procesar en lotes optimizados para evitar timeouts en Supabase
        const EMBEDDING_BATCH_SIZE = 20; // Procesar 20 embeddings a la vez
        const INSERT_BATCH_SIZE = 5; // Insertar solo 5 chunks a la vez (reducido para evitar timeouts)
        const PROGRESS_UPDATE_INTERVAL = 5; // Actualizar progreso cada 5 chunks (más frecuente)
        let processedCount = 0;
        let failedChunks = 0;

        // Función para insertar chunks en Supabase con retry y manejo de timeouts mejorado
        const insertChunksBatch = async (chunksToInsert, retries = 5) => {
            // Si el batch es muy grande, dividirlo inmediatamente
            if (chunksToInsert.length > 5) {
                console.log(`[RAG Worker] Dividiendo batch grande de ${chunksToInsert.length} chunks en batches más pequeños...`);
                const mid = Math.floor(chunksToInsert.length / 2);
                await insertChunksBatch(chunksToInsert.slice(0, mid), retries);
                await insertChunksBatch(chunksToInsert.slice(mid), retries);
                return;
            }

            for (let attempt = 1; attempt <= retries; attempt++) {
                try {
                    // Añadir timeout explícito de 30 segundos por operación
                    const insertPromise = supabase
                        .from('course_content_chunks')
                        .insert(chunksToInsert);
                    
                    const timeoutPromise = new Promise((_, reject) => 
                        setTimeout(() => reject(new Error('Timeout: La inserción tardó más de 30 segundos')), 30000)
                    );
                    
                    const { data, error } = await Promise.race([insertPromise, timeoutPromise]);

                    if (error) {
                        // Si es timeout, dividir el batch inmediatamente
                        if (error.message?.includes('timeout') || 
                            error.message?.includes('statement timeout') || 
                            error.message?.includes('canceling statement') ||
                            error.message?.includes('Timeout:')) {
                            
                            if (chunksToInsert.length > 1) {
                                console.warn(`[RAG Worker] ⚠️ Timeout insertando batch de ${chunksToInsert.length} chunks (intento ${attempt}/${retries}), dividiendo batch...`);
                                const mid = Math.floor(chunksToInsert.length / 2);
                                if (mid > 0) {
                                    await insertChunksBatch(chunksToInsert.slice(0, mid), retries);
                                }
                                if (chunksToInsert.length - mid > 0) {
                                    await insertChunksBatch(chunksToInsert.slice(mid), retries);
                                }
                                return;
                            } else {
                                // Si es un solo chunk y aún falla, esperar más tiempo antes de reintentar
                                if (attempt < retries) {
                                    const waitTime = 5000 * attempt; // Backoff más largo para chunks individuales
                                    console.warn(`[RAG Worker] Esperando ${waitTime}ms antes de reintentar chunk individual...`);
                                    await new Promise(resolve => setTimeout(resolve, waitTime));
                                    continue;
                                }
                            }
                        }
                        throw error;
                    }
                    
                    // Éxito
                    console.log(`[RAG Worker] ✅ Insertados ${chunksToInsert.length} chunks exitosamente`);
                    return;
                } catch (err) {
                    const isTimeout = err.message?.includes('timeout') || 
                                     err.message?.includes('statement timeout') || 
                                     err.message?.includes('canceling statement') ||
                                     err.message?.includes('Timeout:');
                    
                    if (attempt === retries) {
                        console.error(`[RAG Worker] ❌ Error insertando batch después de ${retries} intentos:`, err.message);
                        // Si es timeout y aún tenemos chunks, intentar dividir
                        if (isTimeout && chunksToInsert.length > 1) {
                            console.warn(`[RAG Worker] Último intento: dividiendo batch de ${chunksToInsert.length} chunks...`);
                            const mid = Math.floor(chunksToInsert.length / 2);
                            if (mid > 0) {
                                await insertChunksBatch(chunksToInsert.slice(0, mid), retries);
                            }
                            if (chunksToInsert.length - mid > 0) {
                                await insertChunksBatch(chunksToInsert.slice(mid), retries);
                            }
                            return;
                        }
                        throw err;
                    }
                    
                    // Esperar antes de reintentar (backoff exponencial más largo)
                    const waitTime = 3000 * Math.pow(2, attempt - 1);
                    console.warn(`[RAG Worker] Error en intento ${attempt}/${retries}, esperando ${waitTime}ms antes de reintentar...`);
                    await new Promise(resolve => setTimeout(resolve, waitTime));
                }
            }
        };

        // Procesar chunks en batches para embeddings
        for (let embeddingBatchStart = 0; embeddingBatchStart < chunks.length; embeddingBatchStart += EMBEDDING_BATCH_SIZE) {
            const embeddingBatchEnd = Math.min(embeddingBatchStart + EMBEDDING_BATCH_SIZE, chunks.length);
            const embeddingBatch = chunks.slice(embeddingBatchStart, embeddingBatchEnd);
            
            // Función helper para generar embedding con retry
            const generateEmbeddingWithRetry = async (chunk, chunkIndex, maxRetries = 3) => {
                let lastError = null;
                
                for (let attempt = 1; attempt <= maxRetries; attempt++) {
                    try {
                        const result = await model.embedContent(chunk);
                        if (attempt > 1) {
                            console.log(`[RAG Worker] ✅ Chunk ${chunkIndex + 1} exitoso en intento ${attempt}`);
                        }
                        return {
                            chunkIndex,
                            chunk,
                            embedding: result.embedding.values,
                            success: true
                        };
                    } catch (embeddingError) {
                        lastError = embeddingError;
                        const errorMsg = embeddingError.message || embeddingError.toString();
                        const isNetworkError = errorMsg.includes('fetch failed') || 
                                             errorMsg.includes('ECONNRESET') ||
                                             errorMsg.includes('ETIMEDOUT') ||
                                             errorMsg.includes('timeout') ||
                                             errorMsg.includes('network');
                        
                        if (attempt < maxRetries && isNetworkError) {
                            // Exponential backoff: 2^attempt segundos (2s, 4s, 8s)
                            const delay = Math.pow(2, attempt) * 1000;
                            console.warn(`[RAG Worker] ⚠️ Chunk ${chunkIndex + 1} falló (intento ${attempt}/${maxRetries}): ${errorMsg}. Reintentando en ${delay/1000}s...`);
                            await new Promise(resolve => setTimeout(resolve, delay));
                            continue;
                        } else {
                            // Último intento falló o no es error de red
                            console.error(`[RAG Worker] ❌ Chunk ${chunkIndex + 1} falló después de ${attempt} intentos: ${errorMsg}`);
                            return {
                                chunkIndex,
                                chunk,
                                embedding: null,
                                success: false,
                                error: errorMsg
                            };
                        }
                    }
                }
                
                // Si llegamos aquí, todos los intentos fallaron
                return {
                    chunkIndex,
                    chunk,
                    embedding: null,
                    success: false,
                    error: lastError?.message || 'Error desconocido después de múltiples intentos'
                };
            };
            
            // Generar embeddings en paralelo con retry
            const embeddingPromises = embeddingBatch.map(async (chunk, index) => {
                const chunkIndex = embeddingBatchStart + index;
                return await generateEmbeddingWithRetry(chunk, chunkIndex);
            });

            // Esperar a que se generen todos los embeddings del batch
            const embeddingResults = await Promise.allSettled(embeddingPromises);
            
            // Preparar chunks para insertar (solo los exitosos)
            const chunksToInsert = [];
            for (const result of embeddingResults) {
                if (result.status === 'fulfilled' && result.value.success) {
                    const { chunkIndex, chunk, embedding } = result.value;
                    chunksToInsert.push({
                        course_id: materialInfo.course_id, // INTEGER, requerido
                        unit_id: materialInfo.unit_id || null, // UUID, opcional
                        session_id: materialInfo.session_id || null, // UUID, opcional
                        content: chunk, // TEXT, requerido
                        embedding: embedding, // vector(768)
                        chunk_index: chunkIndex + 1, // INTEGER (no chunk_number)
                        metadata: {
                            material_id: job.metadata?.materialId,
                            page_start: Math.floor((chunkIndex * chunkSize) / 3000) + 1,
                            page_end: Math.floor(((chunkIndex + 1) * chunkSize) / 3000) + 1,
                            file_name: job.file_name,
                            chunk_size: chunkSize
                        }
                    });
                } else {
                    failedChunks++;
                    const errorMsg = result.status === 'fulfilled' ? result.value.error : result.reason?.message || 'Error desconocido';
                    console.warn(`[RAG Worker] ⚠️ Chunk ${result.status === 'fulfilled' ? result.value.chunkIndex + 1 : 'desconocido'} falló: ${errorMsg}`);
                }
            }
            
            // Actualizar progreso después de generar embeddings (antes de insertar)
            // Esto muestra el progreso incluso antes de que se inserten en la BD
            const currentProgress = processedCount + chunksToInsert.length;
            if (currentProgress % PROGRESS_UPDATE_INTERVAL === 0 || chunksToInsert.length > 0) {
                try {
                    await supabase
                        .from('file_processing_jobs')
                        .update({
                            updated_at: new Date().toISOString(),
                            metadata: {
                                ...job.metadata,
                                chunksProcessed: currentProgress,
                                chunksTotal: chunks.length
                            }
                        })
                        .eq('id', job.id);
                    
                    const progressPercent = Math.round((currentProgress / chunks.length) * 100);
                    console.log(`[RAG Worker] 📊 Progreso (embeddings generados): ${currentProgress}/${chunks.length} chunks (${progressPercent}%)`);
                } catch (updateError) {
                    console.warn('[RAG Worker] ⚠️ Error actualizando progreso (no crítico):', updateError.message);
                }
            }

            // Insertar chunks en batches más pequeños para evitar timeouts
            for (let insertBatchStart = 0; insertBatchStart < chunksToInsert.length; insertBatchStart += INSERT_BATCH_SIZE) {
                const insertBatchEnd = Math.min(insertBatchStart + INSERT_BATCH_SIZE, chunksToInsert.length);
                const insertBatch = chunksToInsert.slice(insertBatchStart, insertBatchEnd);
                
                try {
                    await insertChunksBatch(insertBatch);
                    processedCount += insertBatch.length;
                    
                    // Añadir un pequeño delay entre batches para no sobrecargar Supabase
                    if (insertBatchStart + INSERT_BATCH_SIZE < chunksToInsert.length) {
                        await new Promise(resolve => setTimeout(resolve, 500)); // 500ms entre batches
                    }
                    
                    // Actualizar progreso después de cada batch de inserción exitoso
                    // Actualizar cada PROGRESS_UPDATE_INTERVAL chunks o al final
                    if (processedCount % PROGRESS_UPDATE_INTERVAL === 0 || processedCount === chunks.length) {
                        const progressPercent = ((processedCount / chunks.length) * 100).toFixed(1);
                        console.log(`[RAG Worker] 📊 Progreso (chunks insertados): ${processedCount}/${chunks.length} chunks (${progressPercent}%)`);
                        
                        // Actualizar metadata del job con progreso
                        try {
                            await supabase
                                .from('file_processing_jobs')
                                .update({
                                    metadata: {
                                        ...job.metadata,
                                        chunksProcessed: processedCount,
                                        chunksTotal: chunks.length
                                    },
                                    updated_at: new Date().toISOString()
                                })
                                .eq('id', job.id);
                        } catch (updateError) {
                            console.warn('[RAG Worker] ⚠️ Error actualizando progreso (no crítico):', updateError.message);
                        }
                    }
                } catch (insertError) {
                    console.error(`[RAG Worker] ❌ Error insertando batch de chunks ${insertBatchStart + 1}-${insertBatchEnd}:`, insertError.message);
                    failedChunks += insertBatch.length;
                    
                    // Si el error es un timeout, intentar dividir el batch y continuar
                    if (insertError.message?.includes('timeout') || 
                        insertError.message?.includes('statement timeout') || 
                        insertError.message?.includes('canceling statement')) {
                        console.warn(`[RAG Worker] ⚠️ Timeout en batch, intentando dividir y continuar...`);
                        try {
                            // Intentar insertar uno por uno
                            for (const chunk of insertBatch) {
                                try {
                                    await insertChunksBatch([chunk]);
                                    processedCount++;
                                } catch (singleError) {
                                    console.error(`[RAG Worker] ❌ Error insertando chunk individual:`, singleError.message);
                                    failedChunks++;
                                }
                            }
                        } catch (retryError) {
                            console.error(`[RAG Worker] ❌ Error en reintento de batch dividido:`, retryError.message);
                        }
                    }
                    // Continuar con el siguiente batch en lugar de fallar todo
                }
            }
        }

        const completedAt = new Date().toISOString();
        const processingTime = Math.round((new Date(completedAt) - new Date(startedAt)) / 1000 / 60); // minutos
        
        console.log(`[RAG Worker] ========================================`);
        console.log(`[RAG Worker] ✅ PROCESAMIENTO COMPLETADO EXITOSAMENTE`);
        console.log(`[RAG Worker] Job ID: ${job.id}`);
        console.log(`[RAG Worker] Archivo: ${job.file_name}`);
        console.log(`[RAG Worker] Chunks procesados: ${processedCount}/${chunks.length}${failedChunks > 0 ? ` (${failedChunks} fallidos)` : ''}`);
        console.log(`[RAG Worker] Tiempo de procesamiento: ${processingTime} minutos`);
        console.log(`[RAG Worker] ========================================`);

        // 7. Marcar job como completado
        const { error: completeError } = await supabase
            .from('file_processing_jobs')
            .update({
                status: 'completed',
                updated_at: completedAt,
                metadata: {
                    ...job.metadata,
                    completedAt: completedAt,
                    chunksProcessed: processedCount,
                    chunksTotal: chunks.length,
                    processingTimeMinutes: processingTime
                }
            })
            .eq('id', job.id);
        
        if (completeError) {
            console.error(`[RAG Worker] ❌ Error marcando job como completado:`, completeError);
            throw completeError;
        }
        
        console.log(`[RAG Worker] ✅ Job marcado como 'completed' en Supabase`);

        // 8. Actualizar material
        if (job.metadata?.materialId) {
            const { error: materialError } = await supabase
                .from('materials')
                .update({
                    rag_status: 'completed',
                    processed_at: completedAt
                })
                .eq('id', job.metadata.materialId);
            
            if (materialError) {
                console.warn(`[RAG Worker] ⚠️ Error actualizando material (no crítico):`, materialError);
            } else {
                console.log(`[RAG Worker] ✅ Material actualizado con rag_status='completed'`);
            }
        }

        res.status(200).json({
            success: true,
            jobId: job.id,
            chunksProcessed: chunks.length
        });

    } catch (error) {
        console.error(`[RAG Worker] ========================================`);
        console.error(`[RAG Worker] ❌ ERROR EN PROCESAMIENTO`);
        if (job) {
            console.error(`[RAG Worker] Job ID: ${job.id}`);
            console.error(`[RAG Worker] Archivo: ${job.file_name}`);
            console.error(`[RAG Worker] Estado antes del error: ${job.status || 'unknown'}`);
        }
        console.error(`[RAG Worker] Error:`, error.message || error);
        console.error(`[RAG Worker] Stack:`, error.stack);
        console.error(`[RAG Worker] ========================================`);

        // Determinar tipo de error para mensaje más claro
        let errorMessage = error.message || 'Error desconocido';
        const errorDetails = {
            code: error.code,
            status: error.response?.status,
            message: error.message,
            stack: error.stack
        };
        
        console.error('[RAG Worker] Detalles del error:', JSON.stringify(errorDetails, null, 2));
        
        if (error.message?.includes('Timeout') || error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
            errorMessage = `Timeout: El procesamiento del archivo tardó demasiado. Para archivos muy grandes (hasta ${MAX_FILE_SIZE / (1024 * 1024)}MB), el procesamiento puede tardar hasta 60 minutos. Intenta nuevamente o considera dividir el archivo.`;
        } else if (error.message?.includes('too large') || error.message?.includes('demasiado grande')) {
            errorMessage = `Archivo demasiado grande: ${errorMessage}. El límite máximo es ${MAX_FILE_SIZE / (1024 * 1024)}MB.`;
        } else if (error.response?.status === 413 || error.statusCode === 413) {
            errorMessage = 'El archivo excede el límite de tamaño permitido (413 Request Entity Too Large)';
        } else if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED' || error.code === 'ECONNRESET') {
            errorMessage = 'Error de conexión. Verifica tu conexión a internet e intenta nuevamente.';
        } else if (error.message?.includes('memory') || error.message?.includes('Memory') || error.message?.includes('heap')) {
            errorMessage = 'Error de memoria: El archivo es demasiado grande para procesar en una sola ejecución. Considera dividirlo en partes más pequeñas.';
        } else if (error.message?.includes('No Google Drive token found') || error.message?.includes('token')) {
            errorMessage = 'Error de autenticación: No se encontró el token de Google Drive. Por favor, reconecta tu cuenta de Google Drive.';
        } else if (error.message?.includes('No se pudo extraer texto')) {
            errorMessage = error.message; // Ya es descriptivo
        } else if (error.message?.includes('corrupto') || error.message?.includes('inválido') || error.message?.includes('InvalidPDF') || error.message?.includes('Invalid PDF')) {
            errorMessage = error.message; // Ya es descriptivo para PDFs corruptos
        } else if (error.message?.includes('timeout') || error.message?.includes('statement timeout') || error.message?.includes('canceling statement')) {
            errorMessage = `Timeout en base de datos: El procesamiento está generando demasiados chunks y Supabase está tardando demasiado en insertarlos. Esto puede ocurrir con archivos muy grandes (más de 500MB). El job se marcará como fallido, pero puedes intentar procesar el archivo nuevamente o dividirlo en partes más pequeñas.`;
        } else {
            // Error genérico - incluir más detalles
            errorMessage = `Error procesando archivo: ${error.message || 'Error desconocido'}. Si el problema persiste, verifica los logs del worker.`;
        }

        // Marcar job como fallido si tenemos el ID
        if (job?.id) {
            try {
                const updateResult = await supabase
                    .from('file_processing_jobs')
                    .update({
                        status: 'failed',
                        error_message: errorMessage,
                        updated_at: new Date().toISOString()
                    })
                    .eq('id', job.id);

                if (updateResult.error) {
                    console.error('[RAG Worker] Error actualizando job en BD:', updateResult.error);
                } else {
                    console.log(`[RAG Worker] Job ${job.id} marcado como failed con mensaje: ${errorMessage}`);
                }

                // También actualizar el material si existe
                if (job.metadata?.materialId) {
                    const materialUpdate = await supabase
                        .from('materials')
                        .update({
                            rag_status: 'failed',
                            updated_at: new Date().toISOString()
                        })
                        .eq('id', job.metadata.materialId);

                    if (materialUpdate.error) {
                        console.error('[RAG Worker] Error actualizando material en BD:', materialUpdate.error);
                    } else {
                        console.log(`[RAG Worker] Material ${job.metadata.materialId} marcado como failed`);
                    }
                }
            } catch (updateError) {
                console.error('[RAG Worker] Error crítico actualizando estado del job:', updateError);
                // Intentar al menos loguear el error en la consola
                console.error('[RAG Worker] Job ID:', job.id);
                console.error('[RAG Worker] Error original:', errorMessage);
            }
        } else {
            console.error('[RAG Worker] No se puede actualizar el job porque no hay job.id disponible');
        }

        // Enviar respuesta de error
        const errorResponse = {
            success: false,
            error: errorMessage,
            jobId: job?.id,
            errorCode: error.code,
            errorStatus: error.response?.status || error.statusCode,
            timestamp: new Date().toISOString()
        };

        // Solo incluir stack en desarrollo
        if (process.env.NODE_ENV === 'development') {
            errorResponse.details = error.stack;
        }

        console.error('[RAG Worker] Enviando respuesta de error:', JSON.stringify(errorResponse, null, 2));

        res.status(500).json(errorResponse);
    }
};
